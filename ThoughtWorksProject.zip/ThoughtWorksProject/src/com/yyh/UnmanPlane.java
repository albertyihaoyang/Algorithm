package com.yyh;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class UnmanPlane {
	public static void main(String[] args){
		System.out.println(record(args[0], Integer.parseInt(args[1])));
	}
	
	public static String record(String fileName, int ind){
		List<String> cur = analysis(fileName);
		if (ind > cur.size() - 1){
			return "Cannot find " + ind;
		} else {
			return cur.get(ind);
		}
	}
	
	private static List<String> analysis(String fileName){
		List<String> res = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)))){
			String line;
			int ind = 0;
			String plane = "";
			boolean flag = true;
			int[] pos = new int[3];
			while ((line = br.readLine()) != null) {
				if (!flag){
					res.add("Error: " + ind++);
					continue;
				}
				String[] arr = line.split(" ");
				if (ind == 0){//Initial pos 
					if (arr.length != 4){
						flag = false;
						res.add("Error: " + ind++);
						continue;
					}
					plane = arr[0];
					for (int i = 0; i < 3; i++){
						try {
							pos[i] = Integer.parseInt(arr[i + 1]);
						} catch (NumberFormatException e){
							flag = false;
							break;
						}
					}
				} else { // following inputs
					if (arr.length != 7 || !arr[0].equals(plane)){
						flag = false;
						res.add("Error: " + ind++);
						continue;
					}
					for (int i = 0; i < 3; i++){
						try {
							int curPos = Integer.parseInt(arr[i + 1]);
							if (curPos != pos[i]) {
								flag = false;
								res.add("Error: " + ind++);
								continue;
							}
						} catch (NumberFormatException e){
							flag = false;
							break;
						}
					}
					for (int i = 0; i < 3; i++){
						try {
							int delPos = Integer.parseInt(arr[i + 4]);
							pos[i] += delPos;
						} catch (NumberFormatException e){
							flag = false;
							break;
						}
					}
				}
				res.add(plane + " " + ind++ + " " + pos[0] + " " + pos[1] + " " + pos[2]);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
	}
	
}
